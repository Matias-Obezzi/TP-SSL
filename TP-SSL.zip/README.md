# Trabajos Prácticos de Sintaxis y Semántica de los Lenguajes
  
## Profesores
  
Cargo  | Nombre
------------- | -------------
Docente | Oscar Bruno
Auxiliar | Roxana Leituz

## TPs
  
Este repositorio contiene los 3 trabajos prácticos para la promoción de la materia:  
- [Autómata finíto como reconocedor y accionador](AFcRyA/)
- [Análisis sintáctico descendente recursivo](ASDR/)
- [Flex y Bison](FyB/)